/*******************************************************************************
 System Idle Task File

  File Name:
    app_idle_task.c

  Summary:
    This file contains source code necessary for FreeRTOS idle task

  Description:

  Remarks:
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
* Copyright (C) 2020 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *******************************************************************************/
// DOM-IGNORE-END

#include "definitions.h"


/*-----------------------------------------------------------*/

void app_idle_task( void )
{
    /* app_idle_hook() will only be called if configUSE_IDLE_HOOK is set
    to 1 in FreeRTOSConfig.h.  It will be called on each iteration of the idle
    task.  It is essential that code added to this hook function never attempts
    to block in any way (for example, call xQueueReceive() with a block time
    specified, or call vTaskDelay()).  If the application makes use of the
    vTaskDelete() API function  then it is also
    important that app_idle_hook() is permitted to return to its calling
    function, because it is the responsibility of the idle task to clean up
    memory allocated by the kernel to any task that has since been deleted. */

//#error User action required - edit file as described here then remove this line
      /**********************************************************************
      * User action required.                                               *
      * In the source file "config/default/freertos_hooks.c/"               *
      *                                                                     *
      * Add this include directive near the top of the file                 *
      *     #include "app_idle_task.h"                                      *
      *                                                                     *
      * Add a call to this function in the function vApplicationIdleHook()  *
      *     app_idle_task();                                                *
      ***********************************************************************/

    bool rf_suspend = false;
    bool needRfCal  = RF_NeedCal();
    uint8_t count = PDS_GetPendingItemsCount();	

    if (needRfCal || count)   //RF_NeedCal() is a API from RF library
    {
        OSAL_CRITSECT_DATA_TYPE IntState;
        IntState = OSAL_CRIT_Enter(OSAL_CRIT_TYPE_HIGH);
        rf_suspend = BT_SYS_RfSuspendReq(1);
        //once rf_suspend is true, BT internal RF_Suspend_Req_Flag will be set,
        //and BT is forbidden to prepare RF.
        OSAL_CRIT_Leave(OSAL_CRIT_TYPE_HIGH, IntState);

        if (rf_suspend)
        {
            if (count)
            {
                PDS_StoreItemTaskHandler();
            }
            else if  (needRfCal)
            {
                RF_Timer_Cal();
            }
            BT_SYS_RfSuspendReq(0);
        }
    }
}

/*-----------------------------------------------------------*/
/*******************************************************************************
 End of File
 */
